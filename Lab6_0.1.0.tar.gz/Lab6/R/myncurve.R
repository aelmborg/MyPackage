#' Title myncurve
#'
#' @param mu
#' @param sigma
#' @param a
#'
#' @return
#' @export
#'
#' @examples
myncurve = function(mu, sigma, a){
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu + 3*sigma))

  myc=seq(mu-3*sigma,a,length=1000)
  myy=dnorm(myc,mean=mu,sd=sigma)

  polygon(c(mu-3*sigma,myc,a),c(0,myy,0),col="cyan")

  mya=pnorm(a,mean=mu,sd=sigma)-pnorm(mu-3*sigma,mean=mu,sd=sigma)
  mya=round(mya,4)

  print(mya)
}
