#' Title My Confidence Interval
#'
#' @param x
#' @param alpha
#'
#' @return
#' @export
#'
#' @examples
myci = function(x,alpha=0.95){
  n=length(x)
  t=qt(alpha,n-1)
  ci=c()
  ci[1]=mean(x)-t*sd(x)/sqrt(n)
  ci[2]=mean(x)+t*sd(x)/sqrt(n)
  ci
}
